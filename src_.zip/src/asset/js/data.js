const prefixStr = 'mui';
export const jsPrefix = prefixStr;
export const cssPrefix = `${prefixStr}_`;