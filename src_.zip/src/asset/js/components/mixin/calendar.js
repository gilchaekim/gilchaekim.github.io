import Position from '../mixin/position';

import {

} from '../../util/index';
import {cssPrefix} from 'GC-data'

export default {
  mixins: [Position],
  props: {

  },

  data: {
    
  },


  computed: {
    
  },
  connected() {
    
  },

  methods: {
    
  },
  update: {

  }
};