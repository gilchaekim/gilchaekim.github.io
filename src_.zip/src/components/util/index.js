const exampleStr = "exampleId"
let a = 0;

const uniqueId = () => exampleStr+(++a);
  
  



