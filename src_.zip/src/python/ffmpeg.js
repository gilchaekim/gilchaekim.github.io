const { exec } = require('child_process');

// 1️⃣ 이미지 → 영상 변환
console.log("📢 FFmpeg: 프레임을 영상으로 변환 중...");
exec('ffmpeg -framerate 30 -i frames/frame_%d.webp -c:v libx264 -pix_fmt yuv420p -crf 23 -preset slow video.mp4', (error, stdout, stderr) => {
    if (error) {
        console.error(`🔴 FFmpeg 오류: ${error.message}`);
        return;
    }
    console.log("✅ FFmpeg: 영상 생성 완료!");
});
