const puppeteer = require("puppeteer");
const fs = require("fs");
const path = require("path");
const { PuppeteerScreenRecorder } = require("puppeteer-screen-recorder");

const jsonPath = process.argv[2];

if (!jsonPath) {
    console.error("❌ JSON 파일 경로가 필요합니다! 예: node record_quiz.js /json/question_1.json");
    process.exit(1);
}

const outputDir = path.resolve(__dirname, "output");
const videoPath = path.join(outputDir, `${path.basename(jsonPath, ".json")}.mp4`);
const audioLogPath = path.join(outputDir, `${path.basename(jsonPath, ".json")}_sync.json`);

// ✅ 폴더 생성
if (!fs.existsSync(outputDir)) {
    fs.mkdirSync(outputDir, { recursive: true });
}

// 🎥 Puppeteer 실행
async function recordQuizVideo() {
    const browser = await puppeteer.launch({
        headless: false,
        defaultViewport: { width: 1080, height: 1920 },
        args: ["--window-size=1080,2050"],
    });

    const page = await browser.newPage();
    const quizUrl = `http://localhost:8888/html/kcb_01.html?json=${jsonPath}`;
    console.log(`🎥 HTML 실행: ${quizUrl}`);
    await page.goto(quizUrl);

    console.log(`📽️ 녹화 시작: ${videoPath}`);
    const recorder = new PuppeteerScreenRecorder(page, {
        followNewTab: true,
        fps: 30,
        videoFrame: { width: 1080, height: 1920 },
        outputFormat: "mp4"
    });
    await recorder.start(videoPath);

    // ✅ 녹화 시작 후 body 클릭 (퀴즈 시작)
    await page.evaluate(() => document.body.click());

    console.log("⌛ 퀴즈 종료 신호 대기 중...");
    await page.waitForFunction(() => window.quizFinished === true, { timeout: 0 });

    console.log("📢 음성 싱크 데이터 저장...");
    const audioLog = await page.evaluate(() => window.audioLog || []);

    if (audioLog.length === 0) {
        console.warn("⚠️ `window.audioLog` 데이터가 없습니다. 싱크 데이터를 저장하지 않습니다.");
    } else {
        fs.writeFileSync(audioLogPath, JSON.stringify(audioLog, null, 2), "utf-8");
        console.log(`✅ 음성 싱크 데이터 저장 완료: ${audioLogPath}`);
    }

    console.log("🛑 녹화 종료...");
    await recorder.stop();
    await browser.close();

    console.log(`✅ 녹화 완료! 영상 저장됨: ${videoPath}`);
}

// 🎬 실행 시작
recordQuizVideo();
