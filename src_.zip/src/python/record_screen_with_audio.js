const puppeteer = require("puppeteer");
const { spawn } = require("child_process");
const ffmpegPath = require("ffmpeg-static");

const OUTPUT_PATH = "./output/recorded_with_audio.mp4";
const AUDIO_PATH = "./output/recorded_audio.mp3";
const HTML_URL = "http://localhost:8888/html/kcb_01.html"; // HTML 페이지 URL

(async () => {
    console.log("📢 Puppeteer: 브라우저 실행 중...");
    const browser = await puppeteer.launch({
        headless: false, // 브라우저 창을 띄워서 녹화 확인 가능
        defaultViewport: null,
        args: ["--window-size=1920,1080"], // 해상도 설정
    });

    const page = await browser.newPage();
    await page.goto(HTML_URL);
    console.log("📢 Puppeteer: HTML 페이지 로드 완료!");

    // 🎯 HTML 로딩 후 자동으로 body 클릭
    await page.waitForSelector("body");
    await page.evaluate(() => {
        document.body.click();
        console.log("🖱️ 자동 클릭 실행 (body)");
    });

    // 🎬 FFmpeg 실행 (화면 + 오디오 동시 녹화)
    console.log("🎬 FFmpeg: 화면 및 오디오 녹화 시작!");
    const ffmpegProcess = spawn(ffmpegPath, [
        // 🔹 화면 녹화 설정
        "-f", "gdigrab",
        "-framerate", "30",
        "-i", "desktop", // 전체 화면 캡처
        // 🔹 오디오 녹음 (CABLE Output 사용)
        "-f", "dshow",
        "-i", "audio=CABLE Output(VB-Audio Virtual Cable)",
        // 🔹 비디오 및 오디오 인코딩 설정
        "-c:v", "libx264", "-preset", "ultrafast", "-crf", "23",
        "-pix_fmt", "yuv420p", "-r", "30",
        "-c:a", "aac", "-b:a", "192k",
        "-y", OUTPUT_PATH, // 🔹 출력 파일 설정
    ]);

    ffmpegProcess.stderr.on("data", (data) => {
        console.log(`🔴 FFmpeg STDERR: ${data}`);
    });

    // 🟢 HTML에서 checkQuizStatus 이벤트 감지하여 녹화 종료
    console.log("📢 Puppeteer: `checkQuizStatus` 감지 대기 중...");
    await page.exposeFunction("stopRecording", async () => {
        console.log("🎬 Puppeteer: 퀴즈 종료 감지! 녹화 중지...");
        ffmpegProcess.kill("SIGINT"); // 🔹 FFmpeg 종료
        await browser.close();
        console.log(`✅ 녹화 완료! 파일 저장됨: ${OUTPUT_PATH}`);
    });

    // 🟢 HTML에서 `checkQuizStatus('end')` 호출 시 녹화 종료
    await page.evaluate(() => {
        const observer = new MutationObserver((mutations) => {
            mutations.forEach((mutation) => {
                if (mutation.target.innerText.includes("end")) {
                    console.log("🎬 퀴즈 종료 감지됨!");
                    window.stopRecording(); // Puppeteer에서 녹화 종료
                }
            });
        });

        // `checkQuizStatus()` 상태를 감지할 요소 선택 (예: 특정 ID, 클래스)
        const quizStatusElement = document.querySelector("#quizStatus");
        if (quizStatusElement) {
            observer.observe(quizStatusElement, { childList: true, subtree: true });
        }
    });

})();
