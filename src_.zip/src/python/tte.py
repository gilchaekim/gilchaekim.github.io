import time
from obswebsocket import obsws, requests

# OBS WebSocket 연결 정보
host = 'localhost'  # OBS WebSocket 서버 주소
port = 4444         # OBS WebSocket 서버 포트 (기본값 4444)
password = 'vmfhwpr!!33'  # OBS WebSocket 비밀번호 (OBS에서 설정한 비밀번호)

# OBS WebSocket 연결
ws = obsws(host, port, password)

try:
    ws.connect()
    print("OBS WebSocket 연결 성공!")
    
    # 녹화 시작
    print("녹화 시작...")
    ws.call(requests.StartRecording())
    
    # 퀴즈가 진행되는 시간 (예: 10초 동안 녹화)
    time.sleep(10)  # 퀴즈 시간 (원하는 시간으로 수정 가능)
    
    # 녹화 종료
    print("녹화 종료...")
    ws.call(requests.StopRecording())

except Exception as e:
    print(f"Error: {e}")
    
finally:
    # 연결 종료
    ws.disconnect()

print("녹화가 완료되었습니다.")