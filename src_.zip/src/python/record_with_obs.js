const WebSocket = require("ws");
const fs = require("fs");
const path = require("path");

// ✅ OBS WebSocket 설정
const OBS_WEBSOCKET_URL = "ws://localhost:4455";

// ✅ 녹화된 파일이 저장될 폴더 확인 (OBS 설정에서 직접 확인 필요)
const OUTPUT_FOLDER = "C:/Users/YOUR_USERNAME/Videos"; // 🔴 여기를 OBS에서 확인 후 변경
const VIDEO_FILE = path.join(OUTPUT_FOLDER, "obs_recording.mp4");

// ✅ WebSocket 연결
const obs = new WebSocket(OBS_WEBSOCKET_URL);

obs.on("open", async () => {
    console.log("✅ OBS WebSocket 연결 성공!");

    // 🎬 녹화 시작
    await sendOBSCommand("StartRecord");

    console.log("📽️ OBS 녹화 시작...");
    
    // ⏳ 10초 동안 녹화 유지
    setTimeout(async () => {
        console.log("🛑 OBS 녹화 종료 요청...");
        await sendOBSCommand("StopRecord");

        // 🎯 녹화 종료 후 파일이 생성될 때까지 기다림
        waitForFile(VIDEO_FILE, 5000).then(() => {
            console.log(`✅ 녹화 파일 확인 완료: ${VIDEO_FILE}`);
        }).catch(() => {
            console.error("❌ 녹화된 파일을 찾을 수 없습니다!");
        });

        obs.close();
    }, 10000);
});

// 🎯 OBS에 명령 전송하는 함수
async function sendOBSCommand(command) {
    return new Promise((resolve, reject) => {
        obs.send(JSON.stringify({ "request-type": command, "message-id": command }), (err) => {
            if (err) reject(err);
            else resolve();
        });
    });
}

// ✅ 녹화 파일 저장 여부를 확인하는 함수 (최대 5초 대기)
function waitForFile(filePath, timeout) {
    return new Promise((resolve, reject) => {
        const start = Date.now();
        const checkFile = setInterval(() => {
            if (fs.existsSync(filePath)) {
                clearInterval(checkFile);
                resolve();
            }
            if (Date.now() - start > timeout) {
                clearInterval(checkFile);
                reject();
            }
        }, 1000);
    });
}

// ✅ OBS WebSocket 오류 핸들링
obs.on("error", (error) => {
    console.error("❌ OBS WebSocket 오류:", error);
});
