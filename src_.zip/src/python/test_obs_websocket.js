const WebSocket = require("ws");

const OBS_WS_URL = "ws://localhost:4455"; // OBS WebSocket 기본 포트

const ws = new WebSocket(OBS_WS_URL);

ws.on("open", () => {
    console.log("✅ obs-websocket 연결 성공! 🚀");
    ws.close();
});

ws.on("error", (err) => {
    console.error("❌ obs-websocket 연결 실패! 🔥", err.message);
});