const puppeteer = require('puppeteer');
const { PuppeteerScreenRecorder } = require('puppeteer-screen-recorder');
const fs = require('fs');

(async () => {
    const browser = await puppeteer.launch({ headless: false, args: ['--no-sandbox'] });
    const page = await browser.newPage();
    await page.setViewport({ width: 1280, height: 720 });

    console.log("📢 Puppeteer: HTML 페이지 실행 중...");
    await page.goto('http://localhost:8080'); // HTML 페이지 실행

    console.log("📢 Puppeteer: 자동 클릭 실행!");
    await page.evaluate(() => document.body.click());

    // ✅ 녹화기 설정
    const recorder = new PuppeteerScreenRecorder(page);
    console.log("🎬 Puppeteer: HTML 화면 녹화 시작!");
    await recorder.start('./output/recorded_video.mp4'); // 🔴 녹화 시작

    // ✅ 음성 재생 이벤트 감지 (퀴즈 시작 시간 기록)
    const startTime = Date.now();
    let timestamps = [];

    await page.exposeFunction("logAudioStart", (audioId) => {
        const currentTime = (Date.now() - startTime) / 1000; // 초 단위 변환
        console.log(`🎙️ ${audioId} 재생 시작: ${currentTime}초`);
        timestamps.push({ audio: audioId, time: currentTime });
    });

    // ✅ HTML에서 `logAudioStart("question.mp3")` 같은 방식으로 호출 필요
    await page.evaluate(() => {
        const questionAudio = document.getElementById("questionAudio");
        const answerAudio = document.getElementById("answerAudio");

        questionAudio.onplay = () => window.logAudioStart("question.mp3");
        answerAudio.onplay = () => window.logAudioStart("answer.mp3");
    });

    // ✅ 퀴즈가 끝날 때까지 대기
    await page.evaluate(() => {
        return new Promise((resolve) => {
            function checkQuizStatus() {
                if (window.quizFinished) {
                    console.log("✅ Puppeteer: 퀴즈 종료 감지!");
                    resolve();
                } else {
                    requestAnimationFrame(checkQuizStatus);
                }
            }
            checkQuizStatus();
        });
    });

    console.log("🎬 Puppeteer: 녹화 종료!");
    await recorder.stop(); // 🔴 녹화 종료

    await browser.close();
    console.log("✅ Puppeteer: 녹화 완료! `output/recorded_video.mp4` 저장됨!");

    // ✅ 음성 싱크 타이밍 저장
    fs.writeFileSync("./output/audio_timestamps.json", JSON.stringify(timestamps, null, 2));
    console.log("✅ 음성 타이밍 정보 `output/audio_timestamps.json` 저장됨!");
})();
