import pandas as pd
import json
import os
import math
import subprocess
from google.cloud import texttospeech

# 📂 파일 경로 설정
EXCEL_FILE = "questions.xlsx"
JSON_FOLDER = "json"
AUDIO_FOLDER = "audio"
OUTPUT_VIDEO_FOLDER = "output"
# 📂 프로젝트 기본 디렉토리 설정 (Python 실행 위치와 무관하게 지정)
BASE_DIR = os.path.abspath(os.path.dirname(__file__)) 

PUPPETEER_SCRIPT = os.path.join(BASE_DIR, "record_quiz.js")  # record_quiz.js 절대 경로

# 폴더 생성
os.makedirs(JSON_FOLDER, exist_ok=True)
os.makedirs(AUDIO_FOLDER, exist_ok=True)
os.makedirs(OUTPUT_VIDEO_FOLDER, exist_ok=True)

# Google Cloud TTS 클라이언트 설정
client = texttospeech.TextToSpeechClient()

# 📌 1️⃣ Google Cloud TTS 음성 생성 함수
def synthesize_speech(text, filename):
    synthesis_input = texttospeech.SynthesisInput(text=text)
    voice = texttospeech.VoiceSelectionParams(
        language_code="ko-KR",
        name="ko-KR-Wavenet-A",
        ssml_gender=texttospeech.SsmlVoiceGender.MALE
    )
    audio_config = texttospeech.AudioConfig(
        audio_encoding=texttospeech.AudioEncoding.MP3,
        speaking_rate=1.0
    )

    response = client.synthesize_speech(input=synthesis_input, voice=voice, audio_config=audio_config)

    with open(filename, "wb") as out:
        out.write(response.audio_content)
    print(f"✅ 음성 파일 생성 완료: {filename}")

# 📌 2️⃣ 엑셀 데이터 → 4문제씩 JSON 변환
def process_quiz_data():
    df = pd.read_excel(EXCEL_FILE, usecols="A:E", header=None)
    df.columns = ["문제", "보기1", "보기2", "보기3", "정답"]

    num_questions = len(df)
    num_groups = math.ceil(num_questions / 4)
    json_files = []

    for group_index in range(num_groups):
        group_data = []
        start_idx = group_index * 4
        end_idx = min(start_idx + 4, num_questions)

        for index in range(start_idx, end_idx):
            row = df.iloc[index]

            # 파일명 설정
            question_audio = f"{AUDIO_FOLDER}/qu{index+1}.mp3"
            answer_audio = f"{AUDIO_FOLDER}/ans{index+1}.mp3"
            choice_audio_files = [
                f"{AUDIO_FOLDER}/quv{index+1}_1.mp3",
                f"{AUDIO_FOLDER}/quv{index+1}_2.mp3",
                f"{AUDIO_FOLDER}/quv{index+1}_3.mp3",
            ]

            # Google TTS 음성 생성
            if not os.path.exists(question_audio):
                synthesize_speech(row["문제"], question_audio)

            if not os.path.exists(answer_audio):
                synthesize_speech(row["정답"], answer_audio)

            for i, choice_audio in enumerate(choice_audio_files):
                if not os.path.exists(choice_audio):
                    synthesize_speech(row[f"보기{i+1}"], choice_audio)

            # JSON 데이터 추가
            group_data.append({
                "question": {"text": row["문제"], "audio": question_audio},
                "qu1": {"text": row["보기1"], "audio": choice_audio_files[0]},
                "qu2": {"text": row["보기2"], "audio": choice_audio_files[1]},
                "qu3": {"text": row["보기3"], "audio": choice_audio_files[2]},
                "anwer": {"text": row["정답"], "audio": answer_audio}
            })

        # JSON 저장
        json_filename = f"{JSON_FOLDER}/question_{group_index+1}.json"
        with open(json_filename, "w", encoding="utf-8") as f:
            json.dump(group_data, f, ensure_ascii=False, indent=2)
        print(f"✅ JSON 생성 완료: {json_filename}")

        json_files.append(json_filename)

    return json_files

# 📌 3️⃣ Puppeteer를 사용하여 자동 녹화 실행
def record_videos(json_files):
    for json_file in json_files:
        print(f"🎥 {json_file}에 대한 녹화 시작...")
        subprocess.run(f"node {PUPPETEER_SCRIPT} {json_file}", shell=True, check=True)
        print(f"✅ 녹화 완료: {json_file}")

# 실행 함수
def main():
    print("🚀 [1/2] Google TTS 음성 생성 및 JSON 변환 중...")
    json_files = process_quiz_data()

    print("🚀 [2/2] Puppeteer 녹화 실행 중...")
    record_videos(json_files)

    print("🎉 모든 JSON 및 음성 파일 생성, 녹화 완료!")

if __name__ == "__main__":
    main()
