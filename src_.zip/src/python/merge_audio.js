const { spawn } = require('child_process');
const fs = require('fs');
const ffmpegStatic = require('ffmpeg-static'); // FFmpeg 실행 경로 설정

const audioFiles = ["static/qu1.wav", "static/clock1.mp3", "static/end.mp3", "static/ans.wav"];

// ✅ 파일 존재 여부 확인
for (const file of audioFiles) {
    if (!fs.existsSync(file)) {
        console.error(`🔴 오류: '${file}' 파일이 존재하지 않습니다.`);
        process.exit(1);
    }
}

// ✅ FFmpeg 필터 개선 (볼륨 증가 + 오디오 길이 조정)
const ffmpegFilters = `
[1:a]adelay=1967|1967,volume=2.0[a1];
[2:a]adelay=10159|10159,volume=2.0[a2];
[3:a]adelay=15173|15173,volume=2.0[a3];
[4:a]adelay=17031|17031,volume=2.0[a4];
[a1][a2][a3][a4]amix=inputs=4:duration=longest:normalize=0
`;

// ✅ FFmpeg 실행 명령어
const ffmpegArgs = [
    "-y",
    "-i", "./output/recorded_video.mp4",
    "-i", "static/qu1.wav",
    "-i", "static/clock1.mp3",
    "-i", "static/end.mp3",
    "-i", "static/ans.wav",
    "-filter_complex", ffmpegFilters,
    "-c:v", "libx264", "-crf", "23", "-preset", "fast",
    "-c:a", "aac",
    "./output/final_video.mp4"
];

console.log("📢 FFmpeg 실행 중...");
const ffmpegProcess = spawn(ffmpegStatic, ffmpegArgs);

ffmpegProcess.stdout.on("data", (data) => {
    console.log(`🎬 FFmpeg STDOUT: ${data}`);
});

ffmpegProcess.stderr.on("data", (data) => {
    console.error(`🔴 FFmpeg STDERR: ${data}`);
});

ffmpegProcess.on("close", (code) => {
    if (code === 0 && fs.existsSync("./output/final_video.mp4")) {
        console.log("✅ 최종 영상 `output/final_video.mp4` 생성 완료! 🎬");
    } else {
        console.error("🔴 `output/final_video.mp4` 파일이 생성되지 않았습니다. FFmpeg 오류를 확인하세요.");
    }
});
