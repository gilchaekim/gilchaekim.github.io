import asyncio
import websockets

# 🔹 WebSocket 서버 (HTML에서 연결 가능)
async def websocket_server(websocket, path):
    async for message in websocket:
        if message == "READY":
            print("✅ HTML에서 WebSocket 연결됨! 자동 클릭 실행 준비 완료!")

# 🔹 WebSocket 서버 실행 함수
async def main():
    async with websockets.serve(websocket_server, "localhost", 8766):
        print("📡 WebSocket 서버 실행 중 (ws://localhost:8766)")
        await asyncio.Future()  # 종료되지 않도록 대기

# 🔹 asyncio.run()으로 서버 실행
if __name__ == "__main__":
    asyncio.run(main())
